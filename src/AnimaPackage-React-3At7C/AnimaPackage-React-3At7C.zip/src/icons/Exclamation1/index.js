export { Exclamation1 } from "./Exclamation1";
